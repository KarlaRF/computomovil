//
//  storeViewController.swift
//  linkinApp
//
//  Created by Macbook on 4/29/19.
//  Copyright © 2019 Macbook. All rights reserved.
//

import UIKit

class storeViewController: UIViewController {
    @IBOutlet weak var lblcap: UILabel!
    
    @IBOutlet weak var lblshirt: UILabel!
    @IBOutlet weak var lblTotal: UILabel!
    @IBOutlet weak var inpCod: UITextField!
    
    @IBOutlet weak var stpcap: UIStepper!
    
    @IBOutlet weak var stpshirt: UIStepper!
    var tmp: String = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(storeViewController.dismissKeyboard))
        view.addGestureRecognizer(tap)
        
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func stpcap(_ sender: UIStepper) {
        lblcap.text = String(stpcap.value)
    }
    
    @IBAction func stpshirt(_ sender: UIStepper) {
        lblshirt.text = String(stpshirt.value)
    }
    
    @IBAction func buy(_ sender: UIButton) {
        let total = (lblshirt.text as! NSString).doubleValue * 20
        let total1 = (lblcap.text as! NSString).doubleValue * 10
        let total2 = total + total1
        lblTotal.text = String(total2)

        if inpCod.text == "123LP"{
            mostrarAlerta(title: "El código es válido", message: "Obtienes %10           ")
        let total3 = total2 - ((total + total1) * 0.1)
            lblTotal.text = String(total3)

        }
        else{
                mostrarAlerta(title: "El código NO es válido", message: "Obten uno en la trivia          ")
                  lblTotal.text = String(total2)
/*
            let total = (lblshirt.text as! NSString).doubleValue * 20
            let total1 = (lblcap.text as! NSString).doubleValue * 10
            let total2 = total + total1
            lblTotal.text = String(total2)
 */
             }

    }
    func mostrarAlerta(title: String, message: String){
        let alerta = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let noVal = UIAlertAction(title: "Código no valido", style: .default){
            (action) in self.lblTotal.text = "NO valido"}
        let cancelar = UIAlertAction(title: "Cerrar", style: .default, handler: {(action) in self.lblTotal.text = ""})
        //alerta.addAction(noVal)
        alerta.addAction(cancelar)
        present(alerta, animated: true, completion: nil)
        }
        
    @objc func dismissKeyboard() {
        //Causes the view (or one of its embedded text fields) to resign the first responder status.
        view.endEditing(true)
    }
}
