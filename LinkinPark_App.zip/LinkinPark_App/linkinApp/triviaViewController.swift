//
//  triviaViewController.swift
//  linkinApp
//
//  Created by Macbook on 4/29/19.
//  Copyright © 2019 Macbook. All rights reserved.
//

import UIKit

class triviaViewController: UIViewController {

    @IBOutlet weak var sw1: UISwitch!
    @IBOutlet weak var sw2: UISwitch!
    @IBOutlet weak var sw3: UISwitch!
    @IBOutlet weak var lblCod: UILabel!
    var result: Int = 0
    var cod: String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        result = 0
        // Do any additional setup after loading the view.
    }
    
    @IBAction func setsw1(_ sender: UISwitch) {
        if sw1.isOn {
            result = result + 1
        }
    }
    
    @IBAction func setsw2(_ sender: UISwitch) {
        if sw2.isOn {
            result = result + 1
        }
    }
    
    @IBAction func setsw3(_ sender: UISwitch) {
        if sw3.isOn {
            result = result + 1
        }
    }
    
    @IBAction func reintento(_ sender: UIButton) {
        result = 0
        lblCod.text = "Código"
    }
    @IBAction func enviar(_ sender: UIButton) {
        if result < 2{
            lblCod.text = "Sigue participando"
        }
        else{
            lblCod.text = "Ganaste código: 123LP"
            cod = "123LP"
        }
    }
}
